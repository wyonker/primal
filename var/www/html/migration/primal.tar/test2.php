<?php

echo "Value = " . $_POST['dest'] . "<br>";


//echo "PHP Self = " . $_SERVER['PHP_SELF'] . "<br><br>";
// Show all information, defaults to INFO_ALL
//phpinfo();

// Show just the module information.
// phpinfo(8) yields identical results.
//phpinfo(INFO_MODULES);

//$_SERVER['REQUEST_URI'];

?>
